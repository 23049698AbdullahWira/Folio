import { StyleSheet, Text, View, TouchableOpacity, SectionList, Image } from 'react-native';

const datasource = [
    {
        data: [{
            year: "2024",
            imageRef: "https://upload.wikimedia.org/wikipedia/commons/2/2e/Max_Verstappen_2024_Chinese_GP.jpg"
        },
            {
                year: "2023",
                imageRef: "https://live.staticflickr.com/65535/53188655148_d203f20cae_h.jpg"
            }
        ],
        team: "Oracle RedBull Racing",
        driver1: "Max Verstappen",
        driver2: "Sergio Perez",
        bgcolor: "#1E41FF",
        color: "#000000"
    },
    {
        data: [{
            year: "2024",
            imageRef: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/2024-08-25_Motorsport%2C_Formel_1%2C_Gro%C3%9Fer_Preis_der_Niederlande_2024_STP_3806_by_Stepro.jpg/1200px-2024-08-25_Motorsport%2C_Formel_1%2C_Gro%C3%9Fer_Preis_der_Niederlande_2024_STP_3806_by_Stepro.jpg"
        },
            {
                year: "2023",
                imageRef: "https://liquipedia.net/commons/images/thumb/1/1c/Mercedes_W14_E_Performance.jpg/600px-Mercedes_W14_E_Performance.jpg",
            }
        ],
        team: "Mercedes-AMG PETRONAS Formula One Team",
        driver1: "Lewis Hamilton",
        driver2: "George Russell",
        bgcolor: "#C0C0C0",
        color: "#000000"
    },
    {
        data: [{
            year: "2024",
            imageRef: "https://i.ytimg.com/vi/ZGrlWXSMyrA/maxresdefault.jpg"
        },
            {
                year: "2023",
                imageRef: "https://formu1a.uno/wp-content/uploads/2023/06/Ala-anteriore-nuova-scaled.jpg"
            }
        ],
        team: "Scuderia Ferrari",
        driver1: "Charles Leclerc",
        driver2: "Carlos Sainz Jr.",
        bgcolor: "#DC0000",
        color: "#000000"
    },
    {
        data: [{
            year: "2024",
            imageRef: "https://live.staticflickr.com/65535/53093820167_8f737f966a_h.jpg"
        },
            {
                year: "2023",
                imageRef: "https://cdn-1.motorsport.com/images/amp/0oObbqP0/s1000/lando-norris-mclaren-mcl38.jpg"
            }
        ],
        team: "Google Chrome Mclaren Formula 1 Team",
        driver1: "Lando Norris",
        driver2: "Oscar Piastri",
        bgcolor: "#FF8700",
        color: "#000000"
    }
];

const renderItem = ({ item, section }) => {
    return (
        <TouchableOpacity style={styles.itemContainer}>
            <View style={styles.imageContainer}>
                <Image source={{ uri: item.imageRef }} style={styles.imageStyle} />
            </View>
            <View style={styles.driverContainer}>
                <Text style={styles.yearStyle}>{item.year}</Text>
                <Text style={{ fontSize: 18, fontWeight: 'bold', textAlign: 'center', marginBottom: 4 }}>
                    Primary Driver:
                </Text>
                <Text style={[styles.driverText, { textAlign: 'center' }]}>
                    {section.driver1}
                </Text>
                <Text style={{ fontSize: 18, fontWeight: 'bold', textAlign: 'center', marginBottom: 4 }}>
                    Secondary Driver:
                </Text>
                <Text style={[styles.driverText, { textAlign: 'center' }]}>
                    {section.driver2}
                </Text>
            </View>
        </TouchableOpacity>
    );
};

export default function App() {
    return (
        <View style={styles.container}>
            <SectionList
                sections={datasource}
                renderItem={renderItem}
                renderSectionHeader={({ section: { team, bgcolor, color } }) => (
                    <View style={{ backgroundColor: bgcolor, paddingHorizontal: 20, width: '100%',}}>
                        <Text style={[styles.headerText, { color: color }]}>{team}</Text>
                    </View>
                )}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        marginHorizontal: 20,
        marginTop: 40,
        backgroundColor: '#f9f9f9',
    },
    itemContainer: {
        marginVertical: 10,
        backgroundColor: '#ffffff',
        borderRadius: 10,
        padding: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.15,
        shadowRadius: 5,
        elevation: 4,
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: 10,
    },
    imageStyle: {
        width: 280,
        height: 160,
        borderRadius: 8,
        resizeMode: 'cover',
    },
    driverContainer: {
        alignItems: 'center',
    },
    driverText: {
        fontSize: 16,
        color: '#555',
        marginVertical: 2,
    },
    yearStyle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#333',
        marginBottom: 8,
    },
    headerText: {
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: 'center',
        paddingVertical: 12,
        marginBottom: 10,
    },
});
